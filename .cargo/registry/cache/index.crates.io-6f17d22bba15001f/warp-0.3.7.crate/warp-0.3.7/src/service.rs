//! Convert `Filter`s into `Service`s

pub use crate::filter::service::service;
