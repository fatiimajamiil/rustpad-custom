UPDATE migrations_reversible_test
SET some_payload = some_payload - 1;
