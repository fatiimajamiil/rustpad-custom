SELECT id "id!", name from (VALUES (1, null)) accounts(id, name)
