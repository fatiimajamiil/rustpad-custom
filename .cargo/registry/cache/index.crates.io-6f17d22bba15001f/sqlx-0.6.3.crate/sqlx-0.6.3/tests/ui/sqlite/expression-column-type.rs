fn main() {
    let _ = sqlx::query!("select 1 as id");
}
