# wasm-bindgen-test-runner

This is an **experimental** crate for enabling `cargo test --target
wasm32-unknown-unknown`. For more information see the README of
`wasm-bindgen-test`.
