//! # Example: busybox-like CLI (Builder API)
//!
//! ```rust
#![doc = include_str!("../../examples/multicall-busybox.rs")]
//! ```
//!
#![doc = include_str!("../../examples/multicall-busybox.md")]
